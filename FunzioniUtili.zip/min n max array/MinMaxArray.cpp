#include <iostream>

using namespace std;

const int size = 10;

int max_rec(int A[], int size){
	
	if(size == 1)			//caso base
		return A[0];
	else{
		int temp;
		temp = max_rec(A,size-1);
		if(temp > A[size-1])		//verifico se temp e' MAGGIORE del resto dell A[]
			return temp;
		return A[size-1];
	}
}

int min_rec(int A[], int size){
	
	if(size == 1)			//caso base
		return A[0];
	else{
		int temp;
		temp = max_rec(A,size-1);	//verifico se temp e' MINORE del resto dell A[]
		if(temp < A[size-1])
			return temp;
		return A[size-1];
	}
}

int main(){
	int A[size] = {1,54,23,65,3,5,76,99,13,0};
	int max = max_rec(A, size);
	cout << max << endl;
	
}
