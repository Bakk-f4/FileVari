#include <iostream>

using namespace std;

const int size = 10;

void bubbleSortArray(int A[], int size){
	int temp;
	for(unsigned int i = 0; i < size - 1; ++i){		//scorro dal primo all ultimo elemento
		for(unsigned int j = 0; j < size - 1; ++j){	//confronto il primo con il restante degli elementi
			if(A[j] > A[j+1]){			//confronto il prec con il succ
				temp = A[j];			//se il prec e' maggiore del succ allora				
				A[j] = A[j+1];			//faccio la swap
				A[j+1] = temp;
			}
		}
	}
}

int main(){
	int A[size] = {1,54,23,65,3,5,76,99,13,0};
	bubbleSortArray(A, size);
	for(unsigned int i = 0; i < size; ++i){
		cout << A[i] << " ";
	}
	cout << endl;
	
}
