#include <iostream>

using namespace std;

const int size = 10;

int sum_rec(int A[], unsigned int size){
	
	if(size == 0)
		return 0;
	return A[size-1] + sum_rec(A,size-1);
}


int main(){
	int A[size] = {1,54,23,65,3,5,76,99,13,0};
	int max = sum_rec(A, size);
	cout << max << endl;
	
}
