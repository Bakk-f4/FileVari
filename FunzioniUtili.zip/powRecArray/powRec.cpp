#include <iostream>

using namespace std;

const int size = 10;

int pow_rec(int n, unsigned int p){
	
	if(p == 0)
		return 1;		
	return n*pow_rec(n, p-1);
}

int main(){
	int A[size] = {1,54,23,65,3,5,76,99,13,0};
	int max = pow_rec(2, 3);
	cout << max << endl;
	
}
