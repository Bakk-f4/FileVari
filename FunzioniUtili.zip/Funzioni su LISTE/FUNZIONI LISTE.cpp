#include <iostream>
#include <string>

using namespace std;

typedef int Elem;

struct cell{
	
	Elem info;
	cell *next;
};

typedef cell* list;

//---------INTESTAZIONI-----------//
void insertionSort(list &q);

void headInsert(list &l, Elem x);

void InsertMoreElem(list& l);

void insertOrderedElem(list &l, Elem x);

void insertAt(list &l, Elem x, int index);

void print(const list l);

bool isEmpty(const list& q);

Elem getElem(const list l, int index);

bool member(const int x, const list& q);

int size(const list& q);

void tailInsert(list &l, Elem x);

void selectionSort(list &l);



	//mergesort
void mergeSort(list *l);
list Merge(list a, list b);
void splitInHalf(list l, list *frontRef, list *halfRef);
	//mergesort
//---------INTESTAZIONI-----------//

int main(){
	
	
	
return 0;
}
//FUNZIONE GRANDEZZA LISTA
int size(const list& q){
	
	cell *moving = q;
	if(isEmpty(q)){
		return 0;	//la lista contiene 0 elementi
	}
	int cont = 0;
	while(moving != nullptr){
		cont++;
		moving = moving->next;				
	}
	return cont;
}



//FUNZIONE MEMBER CONTROLLO SE ESISTE X IN LISTA
bool member(const int x, const list& q){
	cell *verify = q;			//cella di verifica che scorre
	if(isEmpty(q)){			//verifico se la lista e' vuota
		std::string err = "MEMBER: The Sequence of elements is empty\n";	
		throw err;
	}	
	while(verify != nullptr){		//scorro fino a che nn trovo nullptr
		if(x == verify->info)		//verifico se x fa' parte della lista
			return true;		//se trovo ritorno true;
		verify = verify->next;		//vado avanti alla prossima cella
	}
	return false;				//se nn trovo niente ritorno false
}

//FUNZIONE CHE RESTITUISCE L ELEMENTO IN POSIZIONE INDEX IN LISTA
Elem getElem(const list l, int index){
	
	cell *cur = l;
	int i = 0;
	while(cur != nullptr){
		if(i == index){
			return cur->info;
		}
	i++;
	cur = cur->next;
	}	
		string ElemNotFound = "Element not found\n";
		throw ElemNotFound;

}

//FUNZIONE CHE CONTROLLA SE LA LISTA E' VUOTA
bool isEmpty(const list& q){	
	return (q == nullptr);	
}

//FUNZIONE CHE STAMPA TUTTA LA LISTA
void print(const list l){
	
	cell *cur = l;					//cella di supporto x scorrere
	while(cur != nullptr){				//vado avanti finche' nn arrivo alla fine
		
		std::cout << cur->info << " ";	
		cur = cur->next;
	}
	std::cout << std::endl;
}

//SORT DI ORDINAMENTO LISTA CRESCENTE
void insertionSort(list &q) {
	cell* i = q->next;

	while(i != nullptr){
		cell* succ = i;
		cell* prev = q;
		
		while(prev != i){
		
			if (succ->info < prev->info){
			
				int temp = succ->info;
				succ->info = prev->info;
				prev->info = temp;
			}
		prev = prev->next;
            	}
	i = i->next;
	}
}

//FUNZIONE DI INSERIMENTO IN TESTA
void headInsert(list &l, Elem x){
	
	cell* aux = new cell;
	
	aux->info = x;
	aux->next = l;
	
	l = aux;
	
}

//FUNZIONE DI INSERIMENTO RIPETUTO IN TESTA
void InsertMoreElem(list& l){				//funzione chiamata read
	
	string x = "";
	
	cout<<"Insert new Elem, insert 'exit' to end\n";
	cin >> x;
	while(x != "exit"){
	
		headInsert(l,stoi(x));			//stoi funzione di #include <string>
		cin >> x;			
	}	
}


//FUNZIONE DI INSERIMENTO ELEMENTI IN MODO ORDINATO CRESCENTE
void insertOrderedElem(list &l, Elem x){
	
	if((l == nullptr) || (l->info > x )){	//se lista vuota o se prima cella ha gia' il contenuto x...
		cell*aux = new cell;
		aux->info = x;
		aux->next = l;
	}
	if(l->info == x)			//se gia' abbiamo questo Elem ritorno;
		return;
	else
		insertOrderedElem(l->next, x);//senno richiamo la funzione alla cella successiva
}


//FUNZIONE DI INSERIMENTO ELEMENTI IN UNA CERTA INDEX
void insertAt(list &l, Elem x, int index){
	
	cell*aux = new cell;			//uso due puntatori per tenere traccia delle celle adiacenti
	cell*cur = l;				//puntatore corrente
	aux->next = nullptr;
	cell*prev = nullptr;			//puntatore prima di quello corrente
	
	int i = 0;				//contatore per index
	
	while(cur != nullptr && i != index){	//scorro fino al index desiderato	
		i++;
		prev = cur;
		cur = cur->next;		
	}	
	if(cur != nullptr){				
		if(cur == l){
			aux->next = l;
			l = aux;
		}		
		else{
			aux->next = cur;
			prev->next = aux;
		}		
		return;
	}	
}
//FUNZIONE DI INSERIMENTO IN CODA
void tailInsert(list &l, Elem x){
	cell* aux = new cell;		//creo nuova cella
	aux->info = x;		//assegno il valore
	aux->next = nullptr;		//assegno alla nuova cella nullptr

	cell* tail = l;		//creo cella coda
	while (tail->next != nullptr){ //finche' nn arrivo alla coda vado avanti
		tail = tail->next;
	}
	tail->next = aux;		//la nuova coda sara' la cella creata prima
}


//SELECTION SORT
void selectionSort(list &l){
	
	cell *temp = l;			//intero in tutta la lista fino a nullptr
	while(temp != nullptr){		
		cell *prev = temp;		//tengo traccia della prima cella
		cell *curr = temp->next;	//tengo traccia della cella successiva alla prima
		
		while(curr != nullptr){		//finche' curr e' diverso da nullptr	
			if(prev->info > curr->info)	//confronto l info di prev con curr
				prev = curr;		//inverto prev e curr
			curr = curr->next;		//vado avanti con curr
		}
		//swap					//faccio la swap tra il contenuto delle celle
		Elem x = temp->info;
		temp->info = prev->info;
		prev->info = x;
		
		temp = temp->next;
	}
	
}




								//				FRONT REF		HALF REF	
								//					fR	slow			hR	 nullptr
void splitInHalf(list l, list *frontRef, list *halfRef){	//divido la lista in due sottoliste	[][][][][][]   		[][][][][][]    
	
	list slow = l;						//
	list fast = l->next;
	
	while(fast != nullptr){				//controllo fast fino a nullptr
		fast = fast->next;				//vado avanti di uno su fast
		if(fast != nullptr){				//se fast nn e' arrivato a nullptr vado avanti con entrambi
			fast = fast->next;
			slow = slow->next;
		}		
	}
	
	*frontRef = l;						//
	*halfRef = slow->next;
	slow->next = nullptr;		
}


list Merge(list a, list b){

	list linked = nullptr;					//inizializzo la nuova lista a nullptr
	
	if(a == nullptr)					//se a e' finita, allora mi rimane solo la lista b
		return (b);
	if(b == nullptr)					//se b e' finita, allora mi rimane solo la lista a
		return (a);
	
	if(a->info <= b->info){				//se aInfo < di bInfo allora aInfo sara' l elemento da inserire nella lista
		linked = a;
		linked->next = Merge(a->next, b);		//richiamo merge sul prossimo elemento della linked list
	}							//in poche parole divido la lista fino ad ottenere solo due celle
	else{							//e inserisco al cella con l info minore e cosi' via
		linked = b;
		linked->next = Merge(a, b->next);		
	}
	
	return (linked);
}



void mergeSort(list *l){
	
	list headCell = *l;
	list a;
	list b;
	
	if((headCell == nullptr) || (headCell->next == nullptr)){	//passo base, cioe' quando la headCell e' alla fine della lista
		return;
	}
	splitInHalf(headCell, &a, &b);		//divido in due parti la lista
	mergeSort(&a);					//richiamo merge su A per divere A in altre due liste e cosi' via...
	mergeSort(&b);					//richiamo merge su B per divere B in altre due liste e cosi' via...
	
	*l = Merge(a, b);				//a questo punto prendo le celle rimanenti delle due liste 
							//e le immetto nella lista di partenza ma in ordine
							//confrontando le celle rimanenti con la funzione merge	
}





