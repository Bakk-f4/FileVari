#include <iostream>

using namespace std;



struct dynamic_array {			
					//strutta di dati 
	int* store;			//store con puntatore che punta a array vero e proprio
	unsigned int size;		//size e' la dimensione dell array modificabile
};


//dichiarazioni
void read_d_array(dynamic_array& d);
void print_d_array(const dynamic_array& d);
void set(dynamic_array &d, int index, int value);
int get(const dynamic_array &d, int index);
void resize(dynamic_array &d, unsigned int newSize);
void delete_d_array(dynamic_array &d);
void d_arraySort(dynamic_array &d,string alg);
void bubbleSort(dynamic_array &d);
void insertionSort(dynamic_array &d);
void selectionSort(dynamic_array &d);




int main(){
	try {
		dynamic_array D1;
		
		read_d_array(D1);
		cout <<"Array in disordine\n";
		print_d_array(D1);
		cout <<"Array in ordine\n";
		d_arraySort(D1,"selectionsort");
		print_d_array(D1);
		cout <<"stampa casuale Array \n";
		print_d_array(D1);
		//set(D1, 3, 1);
		//cout << get(D1, 0) << endl;
	}
	catch(string s){
		cerr << s << endl;
	}
	catch(...){
		cerr <<"Unknown Error\n";
	}
	


return 0;
}



void read_d_array(dynamic_array& d) {

	// definire una variabile intera s a un valore negativo
	/* finché s non è strettamente positiva....
		// stampare "Inserisci la dimensione del vettore" e andare a capo
		// leggere s
	*/
	// assegnare s al campo size di d
	// allocare s interi assegnando l ' area di memoria riservata al campo store di d
	/* iterare s volte....
	// stampare "inserisci un valore"
	// leggere un valore nell ' i-esimo elemento del campo store di d...
	// ...usando la notazione con le quadre per accedervi
	*/
	int s = -1;
	while(s <= 0){
		cout << "Inserisci la dimensione del vettore" << endl;
		cin >> s;
	}
	
	d.size = s;
	d.store = new int[s];
	for(unsigned int i = 0; i < s; ++i){
		cout << "Inserisci un valore ";
		cin >> d.store[i];
	}
	
}

void print_d_array(const dynamic_array& d) {
	// definire un puntatore p e inizializzarlo con il campo array di d	
	// usando l ' aritmetica dei puntatori su p per visitare il campo store di d...
	// ...stampare gli elementi del campo store di d, ...
	// ...ciascuno seguito dal carattere ' \t '
	// stampare una andata a capo
	
	int *p = d.store;
	
	for(unsigned int i = 0; i < d.size; ++i){
		cout << *(p+i) << "\t";
	}
	cout << endl;
}


//inserisco il valore value nella posizione index dell' array d
//index e' la posizione dove inseriamo value
//value e' il valore che vogliamo inserire
void set(dynamic_array &d, int index, int value){
	string err = "Out of range error SET";
	if((index < 0) || (index >= d.size)){
		throw err;
	}
	*(d.store + index) = value;
}


//obiettivo leggere contenuto in una posizione
//index e' la posizione che voglio controllare
//return -> (contenuto della posizione index)
//--IMPORTANT--: con const evitiamo che la funzione vada a sporcare l'array
//	     passando con riferimento const evito che venga modificato l' array in 
//	     qualsiasi caso
int get(const dynamic_array &d, int index){
	string err = "Out of range error GET";
	if((index < 0) || (index >= d.size)){
		throw err;
	}
	return *(d.store + index);
	
}



//funzione RESIZE che varia dimensione di array pre-esistente
//prende in input un array dinamico pre-esistente e modifica la dimensione
//casi da verificare : newSize > d.size && !(newSize < d.size)
//PROPRIETA' IMPORTANTE: le celle dell' array sono CONTIGUE in memoria
void resize(dynamic_array &d, unsigned int newSize){
	//creo array nuovo
	int *T = new int[newSize];
	
	//copio il vecchio nel nuovo array
	for (unsigned int i = 0; i < d.size; ++i){
		if (i < newSize){
			*(T+i) = *(d.store + i);
		}
	}
	//cancello vecchio array
	delete[] d.store;
	//assegno il puntatore vecchio al nuovo
	d.store = T;
	d.size = newSize;
}


void delete_d_array(dynamic_array &d){
	if (d.size > 0){
		delete[] d.store;
		d.size = 0;
	}
	else{
		string err = "Errore, l'array inserito non e' valido!\n";
		throw err;
	}	

}


//funzione di ordinamento di array

void d_arraySort(dynamic_array &d, string alg){
	
	string err = "Tipo di ordinamento inserito non valido\nUtilizzare uno di questi tre come parametri\n1: bubblesort\n2:selectionsort\n3:insertionsort\n";
	if( alg == "bubblesort" ){
		bubbleSort(d);
	}
	else if(alg == "selectionsort" ){
		selectionSort(d);
	}
	else if(alg == "insertionsort" ){
		insertionSort(d);
	}
	else{
		throw err;
	}

}

void bubbleSort(dynamic_array &d){
	int aux;
	for(unsigned int i = 0; i < d.size - 1; ++i){
		for (unsigned int j = 0; j < d.size - 1; ++j){
			if(d.store[j] > d.store [j+1]){
				aux = d.store[j];
				d.store[j] = d.store[j+1];
				d.store[j+1] = aux;
			}
		}
	}
}


//nuovo insertion sort
void insertionSort(dynamic_array &d){
	int temp;
	int j;
	for(unsigned int i = 1; i < d.size; ++i){
		temp = d.store[i];
		j = i-1;
		while ((j >= 0) && (temp < d.store[j])){
			d.store[j+1] = d.store[j];
			j--;
		}
		d.store[j+1] = temp;
		
	}
}


void selectionSort(dynamic_array &d){
	
	for(unsigned int i = 0; i < d.size; ++i){
		int smallestIndex = i;
		for(unsigned int j = i + 1; j < d.size; ++j){
			if(d.store[j] < d.store[smallestIndex]){
				smallestIndex = j;
			}
		}
		int temp = d.store[smallestIndex];
		d.store[smallestIndex] = d.store[i];
		d.store[i] = temp;
	}
	
}





















