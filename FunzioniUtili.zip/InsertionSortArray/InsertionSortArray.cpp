#include <iostream>

using namespace std;

const int size = 10;

void insertionSort(int A[], int size){
	for(unsigned int i = 1; i < size; ++i){
		int temp = A[i];			//salvo contenuto della seconda cella
		int j = i - 1;				//salvo index della prima cella
		while(( A[j] > temp ) && (j >= 0)){	//confronto se la prima e' maggiore della seconda e se e' vero faccio la swap
							//cambiare confronto con < se si vuole decrescente
			A[j+1] = A[j];			//controllo anche se j non va' out of bound
			j--;				//diminuisco j per soccere indietro l array
		}
		A[j+1] = temp;				//assegno alla pos giusta la temp salvata in precedenza
	}
}

int main(){
	int A[size] = {1,54,23,65,3,5,76,99,13,0};
	insertionSort(A, size);
	for(unsigned int i = 0; i < size; ++i){
		cout << A[i] << " ";
	}
	cout << endl;
	
}
